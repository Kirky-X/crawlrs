# `derive_more-impl`

This crate is an implementation detail of the [`derive_more`][crates.io]. If you
found this crate by accident you're probably looking for one of the following
pages of [`derive_more`][crates.io]:
1. [crates.io]
2. [docs.rs]
3. [GitHub]

[crates.io]: https://crates.io/crates/derive_more
[docs.rs]: https://docs.rs/derive_more/latest/derive_more
[GitHub]: https://github.com/JelteF/derive_more
