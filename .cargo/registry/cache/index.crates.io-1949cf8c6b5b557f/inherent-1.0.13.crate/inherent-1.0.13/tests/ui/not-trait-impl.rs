use inherent::inherent;

struct Struct;

#[inherent]
impl Struct {
    fn f() {}
}

fn main() {}
