# `sea-bae`

`sea-bae` is a crate for proc macro authors, which simplifies parsing of attributes. It is heavily inspired by [`darling`](https://crates.io/crates/darling) but has a significantly simpler API.

See [the docs](https://docs.rs/sea-bae) for more info.

This fork upgrades `syn` to `2.0` and `heck` to `0.4`, mainly for use in `sea-orm`.
