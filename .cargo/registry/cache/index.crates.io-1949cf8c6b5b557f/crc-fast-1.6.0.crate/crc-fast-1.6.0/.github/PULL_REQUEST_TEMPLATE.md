## The Problem

[ What are you trying to solve? Why are you trying to solve it? ]

## The Solution

[ How are you fixing the problem? High-level explanation. ]

### Changes

[ A more detailed explanation of the solution to guide reviewers. Point out tricky or magic areas. ]

### Planned version bump

- Which: [ `MAJOR`, `MINOR`, `PATCH` ]
- Why: [ non-breaking bug fix, doc change, test coverage, formatting, debugging, profiling, security fix, internal change, experimental change, non-breaking new functionality, breaking change, etc ]

### Links

* [ Any important other PRs, Issues, PRs, etc? ]

## Notes

[ @mentions for anyone who should be alerted to this PR ]

[ **Please assign reviewers if you want someone specific to review this** ]

[ **Please do not forget to add labels specific to this PR** ]
