// Copyright 2014-2017 The html5ever Project Developers. See the
// COPYRIGHT file at the top-level directory of this distribution.
//
// Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
// http://www.apache.org/licenses/LICENSE-2.0> or the MIT license
// <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. This file may not be copied, modified, or distributed
// except according to those terms.

pub use tendril;

#[macro_use]
extern crate web_atoms;

/// Create a [`SmallCharSet`], with each space-separated number stored in the set.
///
/// # Examples
///
/// ```
/// # #[macro_use] extern crate markup5ever;
/// # fn main() {
/// let set = small_char_set!(12 54 42);
/// assert_eq!(set.bits,
///            0b00000000_01000000_00000100_00000000_00000000_00000000_00010000_00000000);
/// # }
/// ```
///
/// [`SmallCharSet`]: struct.SmallCharSet.html
#[macro_export]
macro_rules! small_char_set ( ($($e:expr)+) => (
    $ crate ::SmallCharSet {
        bits: $( (1 << ($e as usize)) )|+
    }
));

pub use web_atoms::{
    local_name, namespace_prefix, namespace_url, ns, LocalName, LocalNameStaticSet, Namespace,
    NamespaceStaticSet, Prefix, PrefixStaticSet,
};

pub mod data {
    pub use web_atoms::C1_REPLACEMENTS;
    pub use web_atoms::NAMED_ENTITIES;
}
#[macro_use]
pub mod interface;
pub mod serialize;
mod util {
    pub mod buffer_queue;
    pub mod smallcharset;
}

pub use interface::{Attribute, ExpandedName, QualName, TokenizerResult};
pub use util::smallcharset::SmallCharSet;
pub use util::*;
