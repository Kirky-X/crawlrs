# metrics-util

[![conduct-badge][]][conduct] [![downloads-badge][] ![release-badge][]][crate] [![docs-badge][]][docs] [![license-badge][]](#license)

[conduct-badge]: https://img.shields.io/badge/%E2%9D%A4-code%20of%20conduct-blue.svg
[downloads-badge]: https://img.shields.io/crates/d/metrics-util.svg
[release-badge]: https://img.shields.io/crates/v/metrics-util.svg
[license-badge]: https://img.shields.io/crates/l/metrics-util.svg
[docs-badge]: https://docs.rs/metrics-util/badge.svg
[conduct]: https://github.com/metrics-rs/metrics/blob/master/CODE_OF_CONDUCT.md
[crate]: https://crates.io/crates/metrics-util
[docs]: https://docs.rs/metrics-util

__metrics-util__ is a helper library with types/functions used within the metrics ecosystem.

## code of conduct

**NOTE**: All conversations and contributions to this project shall adhere to the [Code of Conduct][conduct].
