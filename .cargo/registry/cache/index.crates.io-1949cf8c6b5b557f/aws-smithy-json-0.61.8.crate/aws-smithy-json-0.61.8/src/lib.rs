/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

/* Automatically managed default lints */
#![cfg_attr(docsrs, feature(doc_cfg))]
/* End of automatically managed default lints */
#![allow(clippy::derive_partial_eq_without_eq)]
#![warn(
    // missing_docs,
    rustdoc::missing_crate_level_docs,
    unreachable_pub,
    // Enabling this requires fixing a macro but I don't understand how to do that.
    // rust_2018_idioms
)]

//! JSON Abstractions for Smithy

pub mod deserialize;
mod escape;
pub mod serialize;
