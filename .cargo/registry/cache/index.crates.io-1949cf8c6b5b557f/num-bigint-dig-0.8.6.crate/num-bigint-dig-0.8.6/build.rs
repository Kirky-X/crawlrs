fn main() {
    println!("cargo:rustc-cfg=has_i128");
}
