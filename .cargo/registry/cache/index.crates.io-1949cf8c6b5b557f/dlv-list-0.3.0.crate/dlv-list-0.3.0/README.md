# dlv-list-rs

[![LICENSE](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Build Status](https://travis-ci.org/sgodwincs/dlv-list-rs.svg?branch=master)](https://travis-ci.org/sgodwincs/dlv-list-rs)

Semi-doubly linked list implemented using a vector.

[Documentation](https://docs.rs/dlv-list/)
