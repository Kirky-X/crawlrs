// Sqlite does not support modification of foreign key constraints to existing tables
