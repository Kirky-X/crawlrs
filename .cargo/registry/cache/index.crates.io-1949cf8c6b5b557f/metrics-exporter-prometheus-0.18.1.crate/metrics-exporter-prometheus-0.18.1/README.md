# metrics-exporter-prometheus

[![conduct-badge][]][conduct] [![downloads-badge][] ![release-badge][]][crate] [![docs-badge][]][docs] [![license-badge][]](#license)

[conduct-badge]: https://img.shields.io/badge/%E2%9D%A4-code%20of%20conduct-blue.svg
[downloads-badge]: https://img.shields.io/crates/d/metrics-exporter-prometheus.svg
[release-badge]: https://img.shields.io/crates/v/metrics-exporter-prometheus.svg
[license-badge]: https://img.shields.io/crates/l/metrics-exporter-prometheus.svg
[docs-badge]: https://docs.rs/metrics-exporter-prometheus/badge.svg
[conduct]: https://github.com/metrics-rs/metrics/blob/master/CODE_OF_CONDUCT.md
[crate]: https://crates.io/crates/metrics-exporter-prometheus
[docs]: https://docs.rs/metrics-exporter-prometheus

__metrics-exporter-prometheus__ is a `metrics`-compatible exporter for sending metrics to Prometheus.

## code of conduct

**NOTE**: All conversations and contributions to this project shall adhere to the [Code of Conduct][conduct].
