//! Source code adapted from https://github.com/Peternator7/strum

#![allow(dead_code)]

pub mod enum_iter;
pub mod helpers;
