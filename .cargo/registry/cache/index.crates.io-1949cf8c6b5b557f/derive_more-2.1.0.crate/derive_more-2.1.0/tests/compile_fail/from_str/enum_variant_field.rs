#[derive(derive_more::FromStr)]
enum Enum {
    Unit,
    Tuple(i32),
}

fn main() {}
