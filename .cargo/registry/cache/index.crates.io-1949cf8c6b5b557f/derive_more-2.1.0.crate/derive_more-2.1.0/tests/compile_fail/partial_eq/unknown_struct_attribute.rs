#[derive(derive_more::PartialEq)]
#[partial_eq(unknown)]
struct Foo(i32);

fn main() {}
