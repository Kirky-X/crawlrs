#[derive(derive_more::AsMut)]
union Foo {
    f1: u32,
    f2: f32,
}

fn main() {}
