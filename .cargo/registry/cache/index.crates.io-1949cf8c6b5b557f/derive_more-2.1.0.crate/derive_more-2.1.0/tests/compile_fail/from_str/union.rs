#[derive(derive_more::FromStr)]
union IntOrFloat {
    i: u32,
}

fn main() {}
