#[derive(derive_more::Debug)]
#[debug("Test")]
pub enum Foo {
    Unit
}

fn main() {}
