#[derive(derive_more::From)]
pub union Foo {
    bar: i32,
}

fn main() {}
