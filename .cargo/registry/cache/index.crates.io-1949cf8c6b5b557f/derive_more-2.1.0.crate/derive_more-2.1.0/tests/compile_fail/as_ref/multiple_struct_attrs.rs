#[derive(derive_more::AsRef)]
#[as_ref(forward)]
#[as_ref(forward)]
struct Foo {
    bar: i32,
}

fn main() {}
