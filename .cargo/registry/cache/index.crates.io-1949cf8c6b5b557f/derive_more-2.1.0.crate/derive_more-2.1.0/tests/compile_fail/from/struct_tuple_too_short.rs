#[derive(derive_more::From)]
#[from((i16,))]
struct Point {
    x: i32,
    y: i32,
}

fn main() {}
