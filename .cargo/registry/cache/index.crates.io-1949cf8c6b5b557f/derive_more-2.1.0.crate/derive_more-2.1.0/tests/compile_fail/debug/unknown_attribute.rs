#[derive(derive_more::Debug)]
#[debug(unknown = "unknown")]
pub struct Foo {
    bar: String,
}

fn main() {}
