#[derive(derive_more::AddAssign)]
#[add_assign(skip)]
struct Foo(i32);

fn main() {}
