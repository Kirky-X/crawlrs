#[derive(derive_more::Debug)]
#[debug("Test")]
#[debug("Second")]
pub struct Foo {}

fn main() {}
