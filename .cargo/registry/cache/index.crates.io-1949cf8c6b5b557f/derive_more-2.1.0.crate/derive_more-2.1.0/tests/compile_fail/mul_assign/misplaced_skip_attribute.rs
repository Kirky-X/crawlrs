#[derive(derive_more::MulAssign)]
#[mul_assign(skip)]
struct Foo(i32);

fn main() {}
