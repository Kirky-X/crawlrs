#[derive(derive_more::FromStr)]
#[from_str(rename_all = "Whatever")]
struct Foo;

fn main() {}
