#[derive(derive_more::Display)]
enum Enum {
    Variant { foo: String, bar: String },
}

fn main() {}
