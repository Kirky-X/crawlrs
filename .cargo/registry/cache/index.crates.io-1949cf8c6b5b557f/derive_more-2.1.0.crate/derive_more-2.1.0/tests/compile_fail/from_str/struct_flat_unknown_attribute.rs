#[derive(derive_more::FromStr)]
#[from_str(unknown = "unknown")]
struct Foo;

fn main() {}
