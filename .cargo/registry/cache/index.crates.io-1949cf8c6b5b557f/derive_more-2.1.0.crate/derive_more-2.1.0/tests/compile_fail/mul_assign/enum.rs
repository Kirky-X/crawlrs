#[derive(derive_more::MulAssign)]
enum Foo {
    Bar(i32),
}

fn main() {}
