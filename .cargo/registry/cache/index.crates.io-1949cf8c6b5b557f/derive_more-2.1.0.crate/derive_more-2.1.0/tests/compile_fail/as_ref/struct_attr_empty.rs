#[derive(derive_more::AsRef)]
#[as_ref(forward)]
struct Foo;

fn main() {}
