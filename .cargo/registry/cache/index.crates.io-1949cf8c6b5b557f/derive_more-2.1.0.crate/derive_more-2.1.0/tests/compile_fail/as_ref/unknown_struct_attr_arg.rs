#[derive(derive_more::AsRef)]
#[as_ref(baz)]
struct Foo {
    bar: i32,
}

fn main() {}
