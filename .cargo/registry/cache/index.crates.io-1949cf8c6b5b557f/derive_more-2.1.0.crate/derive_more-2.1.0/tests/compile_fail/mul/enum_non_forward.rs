#[derive(derive_more::Mul)]
enum Foo {
    Bar(i32),
}

fn main() {}
