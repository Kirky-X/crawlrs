#[derive(derive_more::TryFrom)]
union Union {
    field: i32,
}

fn main() {}
