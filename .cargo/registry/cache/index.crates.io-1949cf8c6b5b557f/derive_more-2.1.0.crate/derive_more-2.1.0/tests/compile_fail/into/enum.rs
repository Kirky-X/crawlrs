#[derive(derive_more::Into)]
enum Foo {
    Foo(i32),
}

fn main() {}
