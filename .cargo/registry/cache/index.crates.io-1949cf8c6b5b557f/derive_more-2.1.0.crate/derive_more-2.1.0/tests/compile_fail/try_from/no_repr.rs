#[derive(derive_more::TryFrom)]
enum Enum {
    Variant
}

fn main() {}
