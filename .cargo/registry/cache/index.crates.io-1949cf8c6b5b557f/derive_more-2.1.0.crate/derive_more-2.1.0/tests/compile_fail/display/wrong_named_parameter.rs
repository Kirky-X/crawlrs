#[derive(derive_more::Display)]
#[display("Stuff({bars})")]
pub struct Foo {
    bar: String,
}

fn main() {}
