#[derive(derive_more::Debug)]
pub union Foo {
    bar: i32,
}

fn main() {}
