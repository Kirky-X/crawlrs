#[derive(derive_more::AddAssign)]
struct Foo;

fn main() {}
