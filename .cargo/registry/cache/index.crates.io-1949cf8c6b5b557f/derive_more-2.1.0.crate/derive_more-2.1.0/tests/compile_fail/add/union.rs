#[derive(derive_more::Add)]
union IntOrFloat {
    i: u32,
}

fn main() {}
